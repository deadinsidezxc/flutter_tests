// class CharacterModel {
//   CharacterModel({
//     List<Results>? results,}){
//     _results = results;
//   }
//
//   CharacterModel.fromJson(dynamic json) {
//     if (json['results'] != null) {
//       _results = [];
//       json['results'].forEach((v) {
//         _results?.add(Results.fromJson(v));
//       });
//     }
//   }
//   List<Results>? _results;
//   List<Results>? get results => _results;
//
//   Map<String, dynamic> toJson() {
//     final map = <String, dynamic>{};
//     if (_results != null) {
//       map['results'] = _results?.map((v) => v.toJson()).toList();
//     }
//     return map;
//   }
// }
//
// class Results {
//   Results({
//     String id = '',
//     String date = '',
//     String type = '',
//     String address = '',
//     int price = 0,
//     String status = '',
//   }){
//     _id = id;
//     _date = date;
//     _type = type;
//     _address = address;
//     _price = price;
//     _status = status;
//   }
//
//   Results.fromJson(dynamic json) {
//     _id = json['id'];
//     _date = json['date'];
//     _type = json['type'];
//     _address = json['address'];
//     _price = json['price'];
//     _status = json['status'];
//   }
//   String _id = '';
//   String _date = '';
//   String _type = '';
//   String _address = '';
//   int _price = 0;
//   String _status = '';
//   String get id => _id;
//   String get date => _date;
//   String get type => _type;
//   String get address => _address;
//   int get price => _price;
//   String get status => _status;
//
//   Map<String, dynamic> toJson() {
//     final map = <String, dynamic>{};
//     map['id'] = _id;
//     map['date'] = _date;
//     map['type'] = _type;
//     map['address'] = _address;
//     map['price'] = _price;
//     map['status'] = _status;
//     return map;
//   }
// }








class CharacterModel {
  CharacterModel({
    List<Results>? results,
    Info? info,}){
    _results = results;
    _info = info;
  }

  CharacterModel.fromJson(dynamic json) {
    if (json['results'] != null) {
      _results = [];
      json['results'].forEach((v) {
        _results?.add(Results.fromJson(v));
      });
    }
    _info = json['info'] != null ? Info.fromJson(json['info']) : null;
  }
  List<Results>? _results;
  Info? _info;
  List<Results>? get results => _results;
  Info? get info => _info;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_results != null) {
      map['results'] = _results?.map((v) => v.toJson()).toList();
    }
    if (_info != null) {
      map['info'] = _info?.toJson();
    }
    return map;
  }
}

// "info": {
// "count": 826,
// "pages": 42,
// "next": "https://rickandmortyapi.com/api/character/?page=2",
// "prev": null

class Info {
  Info({
    int count = 0,
    int pages = 0,
    String? next,
    String? prev,}){
    _count = count;
    _pages = pages;
  }

  Info.fromJson(dynamic json) {
    _count = json['count'];
    _pages = json['pages'];
    _next = json['next'];
    _prev = json['prev'];
  }
  int _count = 0;
  int _pages = 0;
  String? _next;
  String? _prev;
  int get count => _count;
  int get pages => _pages;
  String? get next => _next;
  String? get prev => _prev;


  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['count'] = _count;
    map['pages'] = _pages;
    map['next'] = _next;
    map['prev'] = _prev;
    return map;
  }
}

// "results": [
// {
// "name": "Rick Sanchez",
// "status": "Alive",
// "species": "Human",
// "gender": "Male",
// "image": "https://rickandmortyapi.com/api/character/avatar/1.jpeg",
// },
// ...
// ]

class Results {
  Results({
    String name = '',
    String status = '',
    String species = '',
    String gender = '',
    String image = '',
    int id = 0,}){
    _name = name;
    _status = status;
    _species = species;
    _gender = gender;
    _image = image;
    _id = id;
  }

  Results.fromJson(dynamic json) {
    _name = json['name'];
    _status = json['status'];
    _species = json['species'];
    _gender = json['gender'];
    _image = json['image'];
    _id = json['id'];
  }
  String _name = '';
  String _status = '';
  String _species = '';
  String _gender = '';
  String _image = '';
  int _id = 0;
  String get name => _name;
  String get status => _status;
  String get species => _species;
  String get gender => _gender;
  String get image => _image;
  int get id => _id;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['status'] = _status;
    map['species'] = _species;
    map['gender'] = _gender;
    map['image'] = _image;
    map['id'] = _id;
    return map;
  }
}