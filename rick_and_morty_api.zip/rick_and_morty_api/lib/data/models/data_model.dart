class CharacterModel {
  CharacterModel({
    List<Results>? results,}){
    _results = results;
  }

  CharacterModel.fromJson(dynamic json) {
    if (json['results'] != null) {
      _results = [];
      json['results'].forEach((v) {
        _results?.add(Results.fromJson(v));
      });
    }
  }
  List<Results>? _results;
  List<Results>? get results => _results;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_results != null) {
      map['results'] = _results?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class Results {
  Results({
    String id = '',
    String date = '',
    String type = '',
    String address = '',
    int price = 0,
    String status = '',
  }){
    _id = id;
    _date = date;
    _type = type;
    _address = address;
    _price = price;
    _status = status;
  }

  Results.fromJson(dynamic json) {
    _id = json['id'];
    _date = json['date'];
    _type = json['type'];
    _address = json['address'];
    _price = json['price'];
    _status = json['status'];
  }
  String _id = '';
  String _date = '';
  String _type = '';
  String _address = '';
  int _price = 0;
  String _status = '';
  String get id => _id;
  String get date => _date;
  String get type => _type;
  String get address => _address;
  int get price => _price;
  String get status => _status;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['date'] = _date;
    map['type'] = _type;
    map['address'] = _address;
    map['price'] = _price;
    map['status'] = _status;
    return map;
  }
}