import 'package:flutter/material.dart';
import 'package:rick_and_morty_api/presentation/bloc/character_bloc/character_bloc.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';
import 'package:rick_and_morty_api/presentation/pages/search_page/search_page.dart';
import 'package:rick_and_morty_api/presentation/pages/authorization/auth.dart';

import 'core/dictionaries/constants.dart';
import 'core/dictionaries/routes.dart';
import 'core/singletons/local_storage.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Test',
      theme: ThemeData(
        //scaffoldBackgroundColor: const Color.fromRGBO(233, 233, 233, 1),
        primarySwatch: Colors.red,
        appBarTheme: AppBarTheme(color: Colors.white),
      ),
      initialRoute: LocalStorage.getString(AppConstants.LOGIN).isEmpty ? AppRoutes.auth : AppRoutes.allUsers,
      routes: {
        AppRoutes.auth: (context) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => CharacterBloc()..add(CharacterLoadingEvent(page: 1, results: 4)),
            ),
            BlocProvider(
              create: (_) => SummCubit(),
            ),
          ],
          child: AuthPage(),
        ),
        AppRoutes.allUsers: (context) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => CharacterBloc()..add(CharacterLoadingEvent(page: 1, results: 4)),
            ),
            BlocProvider(
              create: (_) => SummCubit(),
            ),
          ],
          child: AllUsers(),
        ),
      },
    );
  }
}