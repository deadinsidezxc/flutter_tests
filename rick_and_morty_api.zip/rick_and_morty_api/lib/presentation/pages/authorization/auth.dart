import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';
import 'package:rick_and_morty_api/presentation/widgets/custom_navigation_bar.dart';

import '../../../core/dictionaries/constants.dart';
import '../../../core/dictionaries/errors.dart';
import '../../../core/singletons/local_storage.dart';
import '../../bloc/character_bloc/character_bloc.dart';
import '../search_page/search_page.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({Key? key}) : super(key: key);

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final TextEditingController _login = TextEditingController();
  final _fromKeyLogin = GlobalKey<FormState>();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 45),
              child: Form(
                key: _fromKeyLogin,
                child: TextFormField(
                  controller: _login,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        color: Colors.black,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    fillColor: Colors.black26,
                    labelText: 'Login',
                    filled: true
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return Errors.requiredField;
                    }
                    return null;
                  },
                  ),
                ),
              ),
            Center(
              child: MaterialButton(
                onPressed: () {
                  if (_fromKeyLogin.currentState!.validate()) {
                    LocalStorage.setString(
                        AppConstants.LOGIN, _login.text.trim());
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (context) => MultiBlocProvider(
                        providers: [
                          BlocProvider(
                            create: (context) => CharacterBloc()
                              ..add(CharacterLoadingEvent(page: 1, results: 20)),
                          ),
                          BlocProvider(
                              create: (_) => SummCubit(),
                          ),
                        ],
                        child: AllUsers(),
                      ),
                    )
                    );
                  }
                  },
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Container(
                    width: 180,
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.black, width: 1.2, style: BorderStyle.solid)
                    ),
                    child: Center(
                      child: Text(
                        'Log in',
                        style: Theme.of(context).textTheme.bodyText1?.merge(
                        TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 24,
                          color: Colors.black.withOpacity(0.8),
                        ),
                      ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const CustomNavigationBar(),
    );
  }
}











