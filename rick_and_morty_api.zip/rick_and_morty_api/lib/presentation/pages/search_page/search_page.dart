import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ionicons/ionicons.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';
import 'package:rick_and_morty_api/presentation/pages/favorite/favorite.dart';
import 'package:rick_and_morty_api/presentation/widgets/amount.dart';
import 'package:rick_and_morty_api/presentation/widgets/custom_list_tile.dart';
import 'package:rick_and_morty_api/presentation/widgets/custom_navigation_bar.dart';
import 'package:rick_and_morty_api/presentation/widgets/status.dart';
import '../../bloc/favorite_cubit/favorite_cubit.dart';
import '../../../core/dictionaries/constants.dart';
import '../../../core/singletons/local_storage.dart';
import '../../../data/models/character_model.dart';
import '../../bloc/character_bloc/character_bloc.dart';
import '../../widgets/custom_bottom_sheet.dart';
import '../authorization/auth.dart';
import '../favorite/favorite.dart';
import '../character_info/character_info.dart';


class AllUsers extends StatefulWidget {
  const AllUsers({Key? key}) : super(key: key);

  @override
  State<AllUsers> createState() => _AllUsersState();
}

class _AllUsersState extends State<AllUsers> {
  late List<Results> users;
  ScrollController scrollController = ScrollController();
  bool isLoading = false;
  int pageCount = 1;
  int summa = 0;
  bool show = true;

  Future<void> _onRefresh() async {
    context
        .read<CharacterBloc>()
        .add(CharacterLoadingEvent(page: 1, results: 4));
    context.read<SummCubit>().nulify();
  }

  @override
  void initState() {
    super.initState();

    void scrollListener() async {
      if (scrollController.position.extentAfter < 150 && !isLoading) {
        isLoading = true;
        context.read<CharacterBloc>().add(CharacterAddElementsEvent(
            page: pageCount, results: 4, oldList: users));
        pageCount += 1;
        await Future.delayed(const Duration(seconds: 1));
        isLoading = false;
      }
    }
    scrollController.addListener(scrollListener);
  }

  // getUsersFromCache() {
  //   String login = LocalStorage.getString(AppConstants.LOGIN);
  //   List<Results> usersFavorite = [];
  //   List<String> cache = LocalStorage.getList('${AppConstants.FAVORITES}$login');
  //
  //   if (cache.isNotEmpty) {
  //     for (var element in cache) {
  //       usersFavorite.add(Results.fromJson(jsonDecode(element)));
  //     }
  //   }
  //
  //   Navigator.of(context).push(
  //     MaterialPageRoute(
  //       builder: (context) => FavoriteUsers(
  //         usersFavorite: usersFavorite,
  //       ),
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<CharacterBloc>().state;
    return Scaffold(
      backgroundColor: const Color.fromRGBO(233, 233, 233, 1),
      appBar: AppBar(
        centerTitle: false,
        leading: IconButton(
          icon: const Icon(Ionicons.arrow_back, color: Colors.black87, size: 30,),
          onPressed: () {
            LocalStorage.remove(AppConstants.LOGIN);
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context) => AuthPage(),
              ),
            );
          },
        ),
        actions: [
          IconButton(
            onPressed: () {
              showSearch(
                context: context,
                delegate: MySearchDelegate(users: users),
              );
            },
            icon: const Icon(Ionicons.search, color: Colors.black87, size: 30,),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: IconButton(
              onPressed: () {
                showSearch(
                  context: context,
                  delegate: MySearchDelegate(users: users),
                );
              },
              icon: const Icon(Ionicons.filter_circle, color: Colors.black87, size: 34,),
            ),
          ),
        ],
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
                'Платежи',
              style: Theme.of(context).textTheme.bodyText1?.merge(
                const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  color: Colors.black87,
                ),
              ),
            ),
          ],
        ),
      ),
      body: listOfUsers(),
      bottomSheet: const CustomBottomSheet(),
      bottomNavigationBar: const CustomNavigationBar(),
    );
  }

  Widget listOfUsers() {
    return BlocBuilder<CharacterBloc, CharacterState>(builder: (context, state) {
      if (state is CharacterLoadingState) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      } else if (state is CharacterFailedState) {
        return Center(
          child: Text(state.message),
        );
      } else if (state is CharacterNetworkExceptionState) {
        return const Center(
          child: Text('No Internet Connection'),
        );
      } else if (state is CharacterDoneState) {
        users = state.users;

        if(users.isNotEmpty) {
          return RefreshIndicator(
            onRefresh: _onRefresh,
            child: ListView.builder(
              controller: scrollController,
              itemCount: users.length,
              itemBuilder: (context, index){
                return Padding(
                    padding: const EdgeInsets.only (top: 10, right: 2),
                  child: MaterialButton(
                    padding: EdgeInsets.zero,
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => BlocProvider(
                            create: (context) => CharacterBloc(),
                            child: CharacterInfo(
                              user: users[index],
                            ),
                          ),
                        ),
                      );
                    },
                    child: SizedBox(
                      child: CustomListTile(
                        results: users[index],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        }
      } else {
        return const Center(
          child: Text('No signals'),
        );
      }
      return const SizedBox.shrink();
    });
  }
}

class MySearchDelegate extends SearchDelegate {
  final List<Results> users;
  late List<Results> searchResultUsers = [...users];

  MySearchDelegate({required this.users});

  @override
  Widget? buildLeading(BuildContext context) {
    IconButton(
      icon: const Icon(Ionicons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
    return null;
  }

  @override
  List<Widget>? buildActions(BuildContext context) => [
    IconButton(
      icon: const Icon(Ionicons.close),
      onPressed: () {
        if (query.isEmpty) {
          close(context, null);
        } else {
          query = '';
        }
      },
    )
  ];

  @override
  Widget buildResults(BuildContext context) {
    return const SizedBox.shrink();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    List<Results> users = searchResultUsers.where((searchResult) {
      final result = searchResult.name;
      final input = query;
      return result.contains(input);
    }).toList();

    return ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: MaterialButton(
              padding: EdgeInsets.zero,
              onPressed: () {
                query = users[index].name;
              },
              child: Container(
                color: Colors.white,
                child: ListTile(
                  title: Text(
                    users[index].name,
                    style: Theme.of(context).textTheme.bodyText1?.merge(
                      const TextStyle(
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  trailing: CharacterStatus(
                      liveState: users[index].status == 'Alive'
                          ? LiveState.alive
                          : users[index].status == 'Dead'
                          ? LiveState.dead
                          : LiveState.unknown
                  ),
                ),
              ),
            ),
          );
        });
  }
}