part of 'character_bloc.dart';

@immutable
abstract class CharacterState {}

class CharacterLoadingState extends CharacterState {}

class CharacterNetworkExceptionState extends CharacterState {}

class CharacterFailedState extends CharacterState {
  final String message;
  CharacterFailedState({required this.message});
}

class CharacterDoneState extends CharacterState {
  final List<Results> users;
  CharacterDoneState({required this.users});
}