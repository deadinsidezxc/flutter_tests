part of 'character_bloc.dart';

@immutable
abstract class CharacterEvent {}

class CharacterLoadingEvent extends CharacterEvent {
  final int page;
  final int results;
  CharacterLoadingEvent({required this.page, required this.results});
}

class CharacterAddElementsEvent extends CharacterEvent {
  final int page;
  final int results;
  final List<Results> oldList;
  CharacterAddElementsEvent({required this.page, required this.results, required this.oldList});
}