import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../../../core/errors/failure.dart';
import '../../../data/repository/character_repo.dart';
import '../../../data/models/character_model.dart';


part 'character_event.dart';
part 'character_state.dart';

class CharacterBloc extends Bloc<CharacterEvent, CharacterState> {
  CharacterBloc() : super(CharacterLoadingState()) {
    on<CharacterLoadingEvent>((event, emit) async {
      emit(CharacterLoadingState());
      final re = await AlarmsInfoRepositoryImpl.getCharacters(
          page: event.page, results: event.results);
      re.fold((l) {
        if (l is ConnectionFailure) {
          emit(CharacterNetworkExceptionState());
        } else if (l is ServerFailure) {
          emit(CharacterFailedState(message: l.message));
        }
      }, (r) => emit(CharacterDoneState(users: r.results!)));
    });

    on<CharacterAddElementsEvent>((event, emit) async {
      final re = await AlarmsInfoRepositoryImpl.getCharacters(
          page: event.page, results: event.results);
      re.fold(
            (l) {
          if (l is ConnectionFailure) {
            emit(CharacterNetworkExceptionState());
          } else if (l is ServerFailure) {
            emit(CharacterFailedState(message: l.message));
          }
        },
            (r) {
          emit(
            CharacterDoneState(users: [...event.oldList, ...r.results!]),
          );
        },
      );
    });
  }
}