// part of 'summ_cubit.dart';
//
// @immutable
// abstract class SummEvent {}
//
// class SummChangeEvent extends SummEvent {
//   final int summ;
//   SummChangeEvent({required this.summ});
// }