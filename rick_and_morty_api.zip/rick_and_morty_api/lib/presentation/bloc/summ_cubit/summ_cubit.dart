import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

class SummCubit extends Cubit<int> {
  SummCubit() : super(0);

  void increment() => emit(state + 2000);
  void incrementing(int price) => emit(state + price);
  void decrement() => emit(state - 2000);
  void decrementing(int price) => emit(state - price);
  void    nulify() => emit(0);
}


// changeSumm(int summ){
//   emit(SummChangeState(summ: summ));
// }

// part of 'summ_cubit.dart';
//
// @immutable
// abstract class SummState {}
//
// class SummInitial extends SummState {}
//
// class SummChangeState extends SummState {
//   final int summ;
//   SummChangeState({required this.summ});
// }