// part of 'summ_cubit.dart';
//
// @immutable
// abstract class SummState {}
//
// class SummChangeDoneState extends SummState {
//   final int summ;
//   SummChangeDoneState({required this.summ});
// }