import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';

enum LiveState { alive, dead, unknown }

class CharacterStatus extends StatelessWidget {
  final LiveState liveState;
  const CharacterStatus({ Key? key, required this.liveState }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Icon(
          Ionicons.document_outline,
          size: 45,
          color: liveState == LiveState.alive
            ? Colors.black45
            : liveState == LiveState.dead
              ? Colors.red
              : Colors.blueAccent
    );
  }
}