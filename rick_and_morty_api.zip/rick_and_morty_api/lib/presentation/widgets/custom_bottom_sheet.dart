import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';
import 'package:rick_and_morty_api/presentation/widgets/payments_popup.dart';

import 'amount.dart';

class CustomBottomSheet extends StatelessWidget {

  const CustomBottomSheet({ Key? key,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SummCubit, int>(
      builder: (context, state) {
        if(state != 0) {
          return BottomSheet(
            enableDrag: false,
            onClosing: () {},
            builder: (context) {
              return Container(
                height: 80,
                width: double.infinity,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: const Color.fromRGBO(233, 233, 233, 1),
                    border: Border.all(color: Colors.black45, width: 1)
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 16, top: 6, bottom: 6),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 200,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  '$state',
                                  style: Theme.of(context).textTheme.bodyText1?.merge(
                                    const TextStyle(
                                      fontSize: 20,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                Text(
                                  ' Р в месяц',
                                  style: Theme.of(context).textTheme.bodyText1?.merge(
                                    const TextStyle(
                                      fontSize: 20,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  (state ~/ 2000).toString(),
                                  style: Theme.of(context).textTheme.caption?.merge(
                                    const TextStyle(
                                      fontWeight: FontWeight.normal,
                                      fontSize: 14,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                const Dogovors(),
                              ],
                            ),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          onPrimary: Colors.white,
                          primary: Colors.red,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        onPressed: (){
                          Navigator.of(context).push(PageRouteBuilder(
                            opaque: false,
                              pageBuilder: (BuildContext context, _, __) => BlocProvider(
                                create: (_) => SummCubit(),
                                child: Payments(),
                              ),
                          ));
                        },
                        child: Text(
                          'оплатить',
                          style: Theme.of(context).textTheme.bodyText1?.merge(
                            const TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        } else {
          return const SizedBox.shrink();
        }
      },
    );
  }
}