// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:ionicons/ionicons.dart';
// import 'package:rick_and_morty_api/presentation/widgets/status.dart';
// import '../../data/models/character_model.dart';
// import '../bloc/summ_cubit/summ_cubit.dart';
//
// class CustomListTileJson extends StatefulWidget {
//   final Results results;
//
//   const CustomListTileJson({ Key? key, required this.results }) : super(key: key);
//
//   @override
//   ListTileState createState() => ListTileState();
// }
//
// class ListTileState extends State<CustomListTileJson> {
//
//   bool _value = false;
//
//   @override
//   Widget build(context) {
//     return CheckboxListTile(
//       controlAffinity: ListTileControlAffinity.leading,
//       value: _value,
//       onChanged: (bool? value) {
//         setState(() {
//           _value = !_value;
//           if(_value) {
//             context.read<SummCubit>().incrementing(widget.results.price);
//           } else {
//             context.read<SummCubit>().decrementing(widget.results.price);
//           }
//         });
//       },
//       tileColor: Colors.white.withOpacity(0.0),
//       activeColor: Colors.red,
//       checkColor: Colors.white,
//       title: ClipRRect(
//         borderRadius: BorderRadius.circular(15.0),
//         child: Container(
//           color: Colors.white,
//           height: 100,
//           child: Padding(
//             padding: const EdgeInsets.all(6.0),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     CharacterStatus(
//                         liveState: widget.results.status == 'Alive'
//                             ? LiveState.alive
//                             : widget.results.status == 'Dead'
//                             ? LiveState.dead
//                             : LiveState.unknown
//                     ),
//                     Column(
//                       mainAxisAlignment: MainAxisAlignment.start,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: [
//                             Text(
//                               widget.results.id,
//                               style: Theme.of(context).textTheme.bodyText1?.merge(
//                                 const TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                   fontSize: 20,
//                                   color: Colors.black,
//                                 ),
//                               ),
//                             ),
//                             Padding(
//                               padding: const EdgeInsets.only(
//                                   left: 4, right: 4),
//                               child: Text(
//                                 'от',
//                                 style: Theme.of(context).textTheme.bodyText1?.merge(
//                                   const TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     fontSize: 20,
//                                     color: Colors.black,
//                                   ),
//                                 ),
//                               ),
//                             ),
//                             Text(
//                               widget.results.date,
//                               style: Theme.of(context).textTheme.bodyText1?.merge(
//                                 const TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                   fontSize: 20,
//                                   color: Colors.black,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                         Text(
//                           widget.results.type,
//                           style: Theme.of(context).textTheme.bodyText1?.merge(
//                             const TextStyle(
//                               color: Colors.black,
//                               fontWeight: FontWeight.normal,
//                               fontSize: 16,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.only(top: 6, bottom: 6),
//                   child: Text(
//                     widget.results.address,
//                     style: Theme.of(context).textTheme.caption?.merge(
//                       TextStyle(
//                         color: Colors.black.withOpacity(0.8),
//                       ),
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 1,
//                   width: 240,
//                   color: Colors.black12.withOpacity(0.2),
//                 ),
//                 Row(
//                   children: [
//                     const Icon(
//                       Ionicons.logo_usd,
//                       size: 15,
//                       color: Colors.green,
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.only(left: 2, right: 35),
//                       child: Text(
//                         'Баланс 100',
//                         style: Theme.of(context).textTheme.bodyText1?.merge(
//                           TextStyle(
//                             fontWeight: FontWeight.bold,
//                             fontSize: 14,
//                             color: Colors.green.shade700,
//                           ),
//                         ),
//                       ),
//                     ),
//                     Text(
//                       'хватит до 20 сентября',
//                       style: Theme.of(context).textTheme.caption?.merge(
//                         TextStyle(
//                           fontWeight: FontWeight.normal,
//                           fontSize: 11,
//                           color: Colors.green.shade700,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }