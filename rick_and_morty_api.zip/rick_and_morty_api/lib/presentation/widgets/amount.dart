import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';

class Dogovors extends StatelessWidget {

  const Dogovors({ Key? key,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
   return BlocBuilder<SummCubit, int>(
       builder: (context, state) {
         if(state ~/ 2000 > 4) {
           return Text(
             ' договоров',
             style: Theme.of(context).textTheme.caption?.merge(
               const TextStyle(
                 fontWeight: FontWeight.normal,
                 fontSize: 14,
                 color: Colors.black,
               ),
             ),
           );
         } else {
           if(state ~/ 2000 > 1) {
             return Text(
               ' договора',
               style: Theme.of(context).textTheme.caption?.merge(
                 const TextStyle(
                   fontWeight: FontWeight.normal,
                   fontSize: 14,
                   color: Colors.black,
                 ),
               ),
             );
           } else {
             return Text(
               ' договор',
               style: Theme.of(context).textTheme.caption?.merge(
                 const TextStyle(
                   fontWeight: FontWeight.normal,
                   fontSize: 14,
                   color: Colors.black,
                 ),
               ),
             );
           }
         }
       }
     );
  }
}