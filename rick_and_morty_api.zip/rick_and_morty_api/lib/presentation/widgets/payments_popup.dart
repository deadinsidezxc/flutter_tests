import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ionicons/ionicons.dart';
import 'package:rick_and_morty_api/presentation/bloc/summ_cubit/summ_cubit.dart';

class Payments extends StatelessWidget {

  const Payments({ Key? key,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SummCubit, int>(
        builder: (context, state) {
          return Scaffold(
            backgroundColor: const Color.fromRGBO(233, 233, 233, 0.95),
            appBar: AppBar(
              centerTitle: false,
                leading: IconButton(
                  icon: const Icon(Ionicons.arrow_back, color: Colors.black87, size: 30,),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              title: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Оплата',
                    style: Theme.of(context).textTheme.bodyText1?.merge(
                      const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 20,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                ],
              )
            ),
            body: Center(
              child: Container(
                height: 300,
                width: 330,
                decoration: BoxDecoration(
                  color: const Color.fromRGBO(233, 233, 233, 1),
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                        color: Colors.black54,
                        blurRadius: 15.0,
                        offset: Offset(0, 0),
                    )
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Оплата на сумму',
                            style: Theme.of(context).textTheme.bodyText1?.merge(
                              const TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          const SizedBox(width: 90),
                          Text(
                            '$state',
                            style: Theme.of(context).textTheme.bodyText1?.merge(
                              const TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          Text(
                            ' Р',
                            style: Theme.of(context).textTheme.bodyText1?.merge(
                              const TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }
    );
  }
}