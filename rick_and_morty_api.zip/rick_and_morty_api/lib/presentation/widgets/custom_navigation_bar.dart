import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ionicons/ionicons.dart';
import 'package:rick_and_morty_api/presentation/pages/search_page/search_page.dart';

import '../../core/dictionaries/constants.dart';
import '../../core/singletons/local_storage.dart';
import '../bloc/character_bloc/character_bloc.dart';
import '../bloc/summ_cubit/summ_cubit.dart';
import '../pages/authorization/auth.dart';

class CustomNavigationBar extends StatefulWidget {
  const CustomNavigationBar({super.key});

  @override
  State<CustomNavigationBar> createState() => _NavigationBarState();
}

class _NavigationBarState extends State<CustomNavigationBar> {
  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      showSelectedLabels: true,
      showUnselectedLabels: false,
      selectedItemColor: Colors.red,
      unselectedItemColor: Colors.black45,
      currentIndex: _selectedIndex,
      onTap: _onItemTapped,
      items: const <BottomNavigationBarItem>[
        // BottomNavigationBarItem(
        //   label: 'Вход',
        //   icon: MaterialButton(
        //       onPressed: () {
        //         LocalStorage.remove(AppConstants.LOGIN);
        //         Navigator.of(context).pushReplacement(
        //           MaterialPageRoute(
        //             builder: (context) => AuthPage(),
        //           ),
        //         );
        //       },
        //     child: const Icon(
        //       Icons.home,
        //       color: Colors.black45,
        //       size: 30,
        //     ),
        //   ),
        // ),

        // BottomNavigationBarItem(
        //   label: 'Платежи',
        //   icon: MaterialButton(
        //     onPressed: () {
        //       LocalStorage.remove(AppConstants.LOGIN);
        //       Navigator.of(context).pushReplacement(
        //         MaterialPageRoute(
        //           builder: (context) => MultiBlocProvider(
        //             providers: [
        //               BlocProvider(
        //                 create: (context) => CharacterBloc()..add(CharacterLoadingEvent(page: 1, results: 4)),
        //               ),
        //               BlocProvider(
        //                 create: (_) => SummCubit(),
        //               ),
        //             ],
        //             child: AllUsers(),
        //           ),
        //         ),
        //       );
        //     },
        //     child: const Icon(
        //       Ionicons.card_outline,
        //       color: Colors.black45,
        //       size: 35,
        //     ),
        //   ),
        // ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.home, size: 30,),
          label: 'Главная',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.card, size: 30,),
          label: 'Платежи',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.grid, size: 30,),
          label: 'Яхзчтоэто',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.chatbox_ellipses, size: 30,),
          label: 'Сообщения',
        ),
        BottomNavigationBarItem(
          icon: Icon(Ionicons.person, size: 30,),
          label: 'Профиль',
        ),
      ],
    );
  }
}