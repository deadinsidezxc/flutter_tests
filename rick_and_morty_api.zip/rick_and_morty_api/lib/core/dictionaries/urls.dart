class Urls{

  static const String srv = 'https://rickandmortyapi.com/api/character';

}