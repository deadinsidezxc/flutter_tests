class AppRoutes{
  static const String auth = '/authorization';
  static const String allUsers = '/allUsers';
  static const String userInfo = '/userInfo';
  static const String favorites = '/favorites';
}