class Errors {
  static const String requiredField = 'Обязательное поле';
  static const String criticalServerErrorTitle = 'Критическая ошибка сервера';
  static const String connectionFailed = 'Отсутствует интернет соединение';
  static const String undefinedPerson = 'Токен недействителен';
}